function A_k = task1(image, k)
  A = double(imread(image));
  [m, n] = size(A);
  [U, S, V] = svd (A);
  Uk = U(1 : m, 1 : k);
  Sk = S(1 : k, 1 : k);
  V = V';
  Vkt = V(1 : k, 1 : n);
  A_k = Uk * Sk * Vkt;
  %imshow(uint8(A_k));
end
