function task5()
  A = double(imread('in/images/image1.gif'));
  [m, n] = size(A);
  k = [1:19 20:20:99 100:30:min(m,n)];
  
  % grafic 1
  [A_k S] = task3('in/images/image1.gif', 125);
  %plot(diag(S), 'b');
  
  % grafic 2
   y1 = [];
   for i = 1 : length(k)
     y1(i) = sum(sum(S(1:k(i), 1:k(i)))) / sum(sum(S(:, :)));
   endfor
  % plot(k, y1, 'b');
  
  % grafic 3
  y2 = [];
  for t = 1 : length(k)
    A_k = task3('in/images/image1.gif', k(t));
    suma = 0;
    for i = 1 : m
      for j = 1 : n
        suma = suma + (A(i, j) - A_k(i, j)) * (A(i, j) - A_k(i, j));
      endfor
    endfor
    y2(t) = suma / (m * n);
  endfor  
  plot(k, y2, 'b');
  
  % grafic 4
  plot(k, (2 * k + 1) / n, 'b');
end