function task2()
  A = double(imread('in/images/image1.gif'));
  [m, n] = size(A);
  
  % grafic 1
  %plot(svd(A), 'b');
  
  k = [1:19 20:20:99 100:30:min(m, n)];
  % grafic 2
   [U, S, V] = svd (A);
   y1 = [];
   for i = 1 : length(k)
     y1(i) = sum(sum(S(1:k(i), 1:k(i)))) / sum(sum(S(:, :)));
   endfor
   %plot(k, y1, 'b');
  
  % grafic 3
  % graficul arata valori, dar sunt valori prea mari pe axa y
  y2 = [];
  for t = 1 : length(k)
    A_k = task1('in/images/image1.gif', k(t));
    suma = 0;
    for i = 1 : m
      for j = 1 : n
        suma = suma + (A(i, j) - A_k(i, j)) * (A(i, j) - A_k(i, j));
      endfor
    endfor
    y2(t) = suma / (m * n);
  endfor  
  plot(k, y2, 'b');
  
  % grafic 4
  %plot(k, (m * k + n * k + k) / (m * n), 'b');
end